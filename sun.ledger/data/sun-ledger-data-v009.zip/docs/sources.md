# Sources

## The text
- Sun Yat-sen, *The International Development of China*, G. P. Putnam's Sons, New York & London, 1922 (preface dated Canton, April 25, 1921). Public domain. Project Gutenberg #45188: https://www.gutenberg.org/files/45188/45188-h/45188-h.htm — page numbers in this project refer to this edition's pagination (the HTML carries the page breaks). Map I (Great Northern Port) is anchor `#ip_18`.
- The "30 million horsepower" Three Gorges figure is from Sun's 1924 *Three Principles of the People* lectures (Principle of Livelihood), not the 1922 book.
- Sun's 1912 pledge of 200,000 li of railway in ten years: statements on becoming Director-General of National Railways, Sept 1912.

## On the plan's afterlife
- *The Legacy of Sun Yat-sen's Railway Plans*, The China Quarterly 111 (Sept 1987), pp. 421–443 — reassesses Lippit's finding that ~80% of 1950–58 rail mileage was in the Nationalists' early-1940s projections (themselves drawn from Sun's 1921 map); Northeast share of rail built: 52.7% (1912–27), 56% (1928–37).
- Mao Zedong, "In Commemoration of Dr. Sun Yat-sen," 12 Nov 1956 (Selected Works vol. 5) — honors Sun; does not mention the Industrial Plan.
- Xi Jinping, speech at the 150th anniversary of Sun's birth, 11 Nov 2016 — names the railways, highways, three ports and Three Gorges and says the blueprint "has long been realized" under the Party (CSIS Interpret translation).
- Pauley Mission report on Soviet removals from Manchuria, 1946 (~$0.9 B direct, ~$2 B replacement, 1946 dollars).
- Covell Meyskens, *Uneasy Allies*, ch. 6 (Three Gorges and Sino-American hydraulic planning; Savage/USBR 1944).

## Data (China)
- Rail, roads, steel, cement, hydro: National Bureau of Statistics yearbooks; China State Railway Group / National Railway Administration year-end releases (165,000 km / 50,000 km HSR at end-2025).
- Ports: Tangshan port authority (884 Mt 2025), Tianjin Port, Shanghai International Port Group (55.06 M TEU 2025), Ningbo-Zhoushan, HK Marine Dept, Shenzhen and Guangzhou port authorities.
- Yangtze trunk freight: Ministry of Transport (pre-2005 points approximate).
- Yellow River sediment: Yellow River Conservancy Commission, Tongguan station decadal means.
- Forest cover: national forest inventories 1–9.
- Population: censuses 1953–2020; pre-1949 provincial estimates; Manchukuo 1940 census.
- GDP per person: Maddison 1990 international dollars (to 2008), extended with real growth.

## Data (United States)
- Rail route-miles: ICC / AAR / BTS. Surfaced roads: FHWA Highway Statistics (series begins 1904). Steel and cement: USGS Minerals Yearbook. Hydro: EIA / FPC. Mississippi system freight and sediment: Army Corps of Engineers, USGS. Containers: Port of LA, Port of Long Beach, PANYNJ. Populations: decennial census (Mountain + Pacific divisions; states west of the Mississippi; Los Angeles County). GDP: Maddison.

## Figures used for inferred targets
- 1920 exchange rate ≈ 2 Mex to the gold dollar. 1920 US plant costs ≈ $60–100 gold per annual tonne of steel, $12–18 per tonne of cement.
- Port of New York 1921: ≈45 million tons by steamship (Port Authority 95th-anniversary history). Suez Canal 1921: ≈20 million tons.
- 1920 census: Philadelphia 1.82 M, New York 5.62 M. US GDP per head 1920 (Maddison): $5,552.

All pre-1949 Chinese figures and pre-1900 American port/river figures are estimates with wide error bars and are marked ≈ in the page's data tables.

## v009 definition audit

See [validation.md](validation.md#primary-source-checks) for primary-source links checked on 29 October 2026 and the claims each supports. The original list above supplies source families rather than a complete point-level trail. Inherited road, port, freight and population comparisons remain provisional where definitions differ. USACE short-ton values require an explicit conversion trail before they can be certified as metric tonnes. No unverified bulk conversion has been made.
