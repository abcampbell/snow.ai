# The program, in Sun's words (1922 Putnam edition, public domain)

**p. vi** Preface, signed “Canton, April 25, 1921.”  
*The whole scheme was drafted between the Armistice and this date, to redeploy the war industries.*

**p. 6** “I, therefore, propose a scheme to develop a new market in China big enough both for her own products and for products from foreign countries. The scheme will be along the following lines: I. The Development of a Communications System. (a) 100,000 miles of Railways. (b) 1,000,000 miles of Macadam Roads. (c) Improvement of Existing Canals … (d) Construction of New Canals … (e) River Conservancy …”  
*The two numbers the rail and road charts are drawn against.*

**p. 7** “II. The Development of Commercial Harbors. (a) Three largest Ocean Ports with future capacity equalling New York Harbor to be constructed in North, Central and South China. (b) Various small Commercial and Fishing Harbors … III. Modern Cities with public utilities to be constructed in all Railway Centers, Termini and alongside Harbors. IV. Water Power Development. V. Iron and Steel Works and Cement Works on the largest scale in order to supply the above needs.”  
*The port yardstick: New York Harbor, about 45 million tons by steamship in 1921.*

**p. 8** “VI. Mineral Development. VII. Agricultural Development. VIII. Irrigational Work on the largest scale in Mongolia and Sinkiang. IX. Reforestation in Central and North China. X. Colonization in Manchuria, Mongolia, Sinkiang, Kokonor, and Thibaut.”  
*Items VI–X of the ten-point program.*

**p. 16** “If within forty years we could develop a city as large as Philadelphia, not to say New York, the land value alone will be sufficient to pay off the capital invested in its development.”  
*The Great Northern Port city. Philadelphia was 1.82 M and New York 5.62 M at the 1920 census.*

**p. 19** “For most of the seven thousand miles of lines under this project are on perfectly level land.”  
*The Northwestern railway system radiating from Dolon Nor.*

**p. 24** “If within ten years we can transport, let us say, ten millions of the people, from the congested provinces of China, to the Northwestern territory to develop its natural resources, the benefit to the commercial world at large will be enormous.”  
*The one target with a date: ten million by 1931.*

**p. 27** “The entire reforestation of its watershed to prevent the washing off of loess is another half of the work in the prevention of flood.”  
*The Yellow River: dikes are half the job, trees the other half.*

**p. 29** “Let us say a capital of from five hundred to a thousand million dollars Mex. should be invested in this project.”  
*Shanxi–Hebei iron and coal and a steel works. No tonnage given.*

**p. 54–55** “… $300,000,000 for the completion of the entire project for the regulating of the Yangtze River … this project will be more profitable than either the Suez or Panama Canal.”  
*Ocean ships to Hankou; Suez carried about 20 million tons in 1921.*

**p. 74** “To improve the Upper Yangtze, the rapids should be dammed up to form locks to enable crafts to ascend the river as well as to generate water power.”  
*Three Gorges. The 30-million-horsepower figure is from his 1924 lectures.*

**p. 75** “… a capital of one to two hundred million dollars should be invested for the supply.”  
*Cement works along the Yangtze limestone.*
