# v009 validation — 29 October 2026

The calculations reproduce after correcting an aggregate-endpoint bug. The 2012 pooled result describes the selected index and depends on the basket. A source-definition audit identifies material coverage problems; most inherited values still lack point-level citations. Numerical agreement establishes reproducibility, while the source gaps below limit interpretation.

## Comparison audit

| Key | China / US pairing | Finding and follow-up |
|---|---|---|
| rail | National operating network / US route-miles | Broadly analogous length concept; reconcile operating-route coverage, freight/passenger inclusion and historical changes. Inherited anchors need exact releases. |
| road | National highway series with a coverage splice / surfaced roads | Material mismatch. Chinese census coverage and surface quality differ; repair the 2000 and 2005 breaks before assigning a historical completion year. |
| bohai | Tangshan + Tianjin / changing largest US port | Two Chinese ports versus a shifting single-port series. Rebuild with stable comparable areas; verify short-ton conversions. |
| east | Shanghai + Ningbo-Zhoushan / LA + Long Beach | Both are grouped ports, but geographic scope, component start dates and handling counts need explicit definitions. Container target is imputed. |
| pearl | Shenzhen + Guangzhou / NY/NJ | Grouped ports with different boundaries. Hong Kong is plotted but excluded from this composite. Container target is imputed. |
| steel | National crude steel / national crude steel | Broadly analogous national output; verify exact source editions and metric-ton conversions for US historical anchors. |
| cement | National cement / national cement | Broadly analogous national output; check cement versus clinker and US conversion history. |
| yz | Yangtze main-stem proxy / Mississippi system freight | Coverage and counting are unresolved: port handling, channel passage and cargo carried are distinct. Early Chinese backfills are estimates. |
| hydro | National installed hydro capacity / national hydro capacity | Verify conventional versus pumped storage and capacity basis in both series. The target supplements the 1921 plan with a 1924 statement; national capacity is also a proxy for a named project. |
| yr | Tongguan sediment / Mississippi sediment | Different river systems and measurement locations. Halving is imputed; flood control and ecological outcomes extend beyond sediment mass. |
| forest | Chinese inventory cover / US forest percentage | National percentages need consistent definitions, land denominators and inventory vintages. Near-flat US history makes target z hit the winsor floor. |
| xj | Xinjiang Han stock / Mountain + Pacific population stock | Ethnic subgroup versus all residents in a broad US region; stocks include natural increase. The +10 M migration proposal is adapted to these stocks. |
| cotton | Xinjiang cotton / national US cotton | Subnational versus national production. Target is imputed. |
| ne | Northeast population / population west of Mississippi | Different regional definitions; population growth includes births. Reuses the Northwestern settlement proposal outside its stated geography and duplicates its weight with xj. |
| cities | Tianjin municipality / LA County | Different administrative areas with changing boundaries. Neither is the newly built Great Northern Port city described in the source. |
| gdp | National GDP/head / national GDP/head | Shared stated 1990-dollar unit; verify the Maddison vintage and post-2008 extension for both countries. GDP/head differs conceptually from infrastructure scale. |

These judgments follow the embedded series definitions. “Broadly analogous” indicates a narrower conceptual mismatch, with point-level verification still outstanding.

## Primary-source checks

- **Road census conflict:** the [NBS second national road census](https://www.stats.gov.cn/sj/tjgb/qttjgb/qgqttjgb/202302/t20230218_1913243.html) gives 1,679,800 km at end-2000; the inherited series has 1,402,700 km. Using the page's mile conversion, the census total already exceeds one million miles. The page therefore labels 2002 as the embedded model's crossing and marks the score partial. A revised historical series needs consistent census coverage and evidence about Sun's macadam requirement.
- **Later road break:** [Jiangsu's transport authority](https://jtyst.jiangsu.gov.cn/art/2007/12/26/art_42001_7513854.html) describes the 2006 survey adjustment to 2005, adding village roads and reducing some ungraded county/township road counts. The [NBS 2010 yearbook](https://www.stats.gov.cn/sj/ndsj/2010/html/P1602C.HTM) reports the revised 2005 total of 3,345,200 km. The ledger's splice scales post-2005 growth to its 2004 level; it is a constructed index rather than observed constant-definition mileage.
- **US road surfaces:** [FHWA HM-12](https://www.fhwa.dot.gov/policyinformation/statistics/2024/hm12.cfm) distinguishes paved from unpaved mileage. This supports the need to harmonize road surface categories; it does not independently verify the inherited US time series.
- **Ports and units:** [USACE port geography](https://www.iwr.usace.army.mil/About/Technical-Centers/WCSC-Waterborne-Commerce-Statistics-Center/WCSC-Navigation-Infrastructure/) uses defined port and statistical-area boundaries. Its [coastal navigation statistics](https://www.iwr.usace.army.mil/Missions/Value-to-the-Nation/Fast-Facts/Coastal-Navigation-Fast-Facts/) use short tons. The inherited figures labeled metric tonnes cannot be certified without their original tables and conversion trail; no blanket conversion has been applied.
- **Population units:** the [Census geography glossary](https://www.census.gov/programs-surveys/geography/about/glossary.html) distinguishes counties, incorporated places and urban areas. Administrative population counts require harmonized boundaries before interpreting the Tianjin/LA comparison as city growth.
- **River freight:** the [NDRC's report of the Yangtze authority's 2024 release](https://cjjjd.ndrc.gov.cn/gongzuodongtai/bumendongtai/202412/t20241227_1395197.htm) gives an expected 4.02 billion tonnes of main-stem port throughput, alongside separate pilotage and hub measures. The inherited 3.9 billion tonne endpoint remains provisional: its accounting concept and original table have not been established. Replacing one endpoint with a differently counted statistic would leave the historical series inconsistent.
- **Hydro:** [EIA's hydropower definitions](https://www.eia.gov/energyexplained/hydropower/) distinguish conventional and pumped-storage facilities. Capacity coverage needs to be specified in both inherited series.
- **Sun's text:** [the 1922 edition](https://www.gutenberg.org/files/45188/45188-h/45188-h.htm) puts the ten-million settlement proposal in the Northwestern territory (p. 24). At p. 27 the two halves refer to engineering work and watershed reforestation; a numerical sediment-halving target is an editorial imputation. The retained +10 M regional stock proxies and their geographic reuse are disclosed in the page.

## Calculation corrections

The v008 sum used zero for any missing component year, including years after a port's last observation. At 2025 Bohai fell from a two-port total to Tangshan alone, while the delta fell to Shanghai alone. v009 truncates these aggregates at common component coverage (2024) and carries the total to the common 2025 end. The unused latest individual anchor remains visible in its own chart. Filled endpoint years stay outside the aggregate's standardization statistics.

The inherited assumption of zero before a later component's first observation remains. A reporting start can differ from the beginning of actual activity; this requires further historical backfill and is not resolved by the endpoint correction.

Log interpolation now retains observation anchors exactly. Previously floating-point reconstruction could put a value infinitesimally above an identical target, shifting a crossing by a year. The Mississippi 0.2 Gt observation now crosses the 0.2 Gt target in 1980.

## Sensitivity and reproducibility

See [findings.md](findings.md) for the eight scenarios, [sensitivity.csv](../data/sensitivity.csv) for full results, and [leave_one_out.csv](../data/leave_one_out.csv) for all sixteen individual exclusions. A crossing is searched on the interpolated annual grid. The China/US comparison reports the first year at or above the US after 1950, matching the inherited search window; it can miss earlier relative positions and need not imply a sustained lead. Sparse anchors and estimates do not support one-year empirical precision.

The early-record test removes only the Chinese PRE object; other estimates embedded in the raw series remain. Each scenario retains constant membership across all 151 years. The four-series row is a narrower basket, not a completed harmonization of all source data. No probability distribution or confidence interval has been fitted.

`node scripts/validate.mjs` checks 9,664 per-series year values against the separate JSON-driven implementation in both modes, all composite years, bounded finite z values, membership, target crossings, exact anchor equality, aggregate endpoints, provenance, and export freshness. The validation summary is [validation.json](../data/validation.json). Regression and source checks serve different purposes: unresolved definitions remain unresolved when parity checks pass.

## Next data repair

1. Rebuild Chinese and US road series on compatible surface and coverage definitions, resolving the official 2000 census and 2005 rebase.
2. Choose stable port boundaries and recover the original yearly tables, with explicit unit conversions and component coverage.
3. Replace regional population-stock proxies with migration flows or keep them explicitly as separate descriptive measures. Harmonize city boundaries before giving them weight in a cross-country development claim.
4. Recover point-level sources for river freight, hydro capacity scope and the Maddison extension. Then rerun the scenarios before changing the main conclusion.

## Browser check

`node scripts/render_check.mjs` passed at 1200×1150 and 390×1000. It verifies sixteen chart cards, eight scenario rows, own/pooled and log/linear toggles, war-shading controls, populated SVGs and finite coordinates. Desktop and narrow-width captures in `qa/` were visually inspected. The narrow table uses horizontal scrolling. Tests run in an isolated headless Chrome profile with installed fallback fonts; external Google font rendering is outside this check.
