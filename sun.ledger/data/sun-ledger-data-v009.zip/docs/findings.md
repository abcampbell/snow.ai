# Findings (v009 validation, 29 Oct 2026)

## What Sun proposed (1921) and what happened
Almost every physical target was built, mostly 1950–2020, at a scale beyond the ask; none of it through the financing he proposed (an Allied consortium, state-owned, foreign-managed until repaid). Scorecard in `data/scorecard.csv`: 12 built, 4 partial (road specification/coverage, ocean ships to Hankou, Grand Canal, the ten-year settlement pace), 2 never (Yellow River navigation to Lanzhou, the international consortium).

Headline years: rail 100,000 mi reached 2024; roads: inherited series crosses 1,000,000 mi in 2002, while the official 2000 census already exceeds that level under its coverage; road completion is now partial pending definition reconciliation; Caofeidian (the Great Northern Port site) 2005, Tangshan now #2 in the world by tonnage; Yangshan 2005 (Hangzhou Bay, as he said); Three Gorges 2012 (22.5 GW vs his 30 M hp ≈ 22 GW); Bingtuan 1954 = his demobilized-soldier colonization mechanism; Huai outlets 1950–53; Wuhan and Nanjing bridges 1957/1968.

## Did Mao get credit?
In his lifetime, nearly all of it (Harness the Huai, the Yellow River slogan, *Swimming*, the First Five-Year Plan). The 1956 Sun commemoration doesn't mention the Industrial Plan. The CCP gave the blueprint credit back officially in 2011–2016; Xi's 150th-anniversary speech lists the railways, roads, ports and Three Gorges and says the Party realized them.

## How much did the civil war derail it?
1921→1949: +6,700 route-miles on paper (over half Japanese-built in the Northeast); ~6,800 mi actually running in 1949, less than in 1921. Steel 0.92 Mt (1943 peak, Anshan) → 0.16 Mt (1949). Soviet removals ~$2 B replacement value. GDP/head −20% 1938→1950. The 1945–49 war cost roughly a decade; the warlord/Japan years cost thirty; the Great Leap and Cultural Revolution another fifteen. Outer Mongolia (the Urga–Kiakhta branch) left for good. The civil war also produced the unitary state his land-requisition financing assumed.

## Who built it (era split, `data/era_split.csv`)
Before 1949: blueprints, surveys, technocrats, ~110,000 km Nationalist roads, Japanese Manchuria (then stripped). Mao 1949–76: the geography and institutions (Lanxin railway 1962, Bingtuan, Huai, bridges, Gezhouba begun 1970), 16% of today's rail, 40% of plain road mileage, 2–3% of tonnage. After 1976: 71% of rail, all expressways, 95–99% of steel, hydro, ports, income.

Against Sun's own 1920 yardsticks rather than today's, Mao's era reached most of them (steel 5–10 Mt by 1957–65; cement likewise; Tianjin and Guangzhou past 1920 New York by the 1960s–80s).

## Composite (`data/composite_timeseries.csv`, `data/results_per_series.csv`)
Sixteen measures, log10, z-scored over 1875–2025, winsorized ±3, floored before existence, carried forward after last data year.
- China, own distribution: Sun bar z = 0.58 (0.50 without imputed targets); crossed 1995 (1977 without imputed); now +1.62.
- US, own distribution: Sun bar −0.59; crossed 1922; now +0.93. Eight of sixteen US series were past his targets by 1921.
- Own-distribution lines cross in 1997 — this does NOT mean China passed the US; it means China was further along its own curve.
- Pooled (shared scale, inherited definitions): Sun bar 0.20 (US targets) / 0.05 (China targets); US passed 1958, China 1994; China's selected composite first reaches the US after 1950 in 2012 (2025 levels: China 1.15, US 1.00); this depends on measure selection and unharmonized definitions; China above the US on 9 of 16 (the three port measures, steel, cement, river freight, hydro, cotton, Tianjin vs LA) and below on 7 (rail route-miles, surfaced roads, income, forest, sediment, both settlement measures).
- End levels are the shape of history: hockey sticks end near +2.5, straight exponentials near +1.7, peaked series near 0. US rail route-miles (peak 1916) score −0.98; US steel (peak 1973) +0.55.

## Known weak points
- Pre-1949 Chinese and pre-1900 US series are estimates (≈ in tables).
- Six of sixteen Sun targets are imputed (containers ×2, forest, silt, cotton, income); the page shows the bar with and without them.
- Municipal boundary changes flatter later city populations.
- The road count breaks in 2005 (village roads added); the composite carries the old caliber forward at the new caliber's growth rate.

## Validation results and limits

The historical narrative above is inherited; this pass checks numerical reproducibility and selected source definitions, rather than independently verifying every historical claim. See [validation.md](validation.md) for the series audit and linked primary sources. The road score has changed from built to partial because the network proxy does not establish Sun’s macadam specification and its 2000 census coverage conflicts with the inherited point.

| Scenario | Measures | China / Sun, own z | China / US, pooled, first ≥ after 1950 | 2025 pooled gap (China − US) |
|---|---:|---:|---:|---:|
| All sixteen | 16 | 1995 | 2012 | +0.155 |
| Exclude imputed targets and their measures | 10 | 1977 | 2009 | +0.203 |
| Text-tagged targets only, including 1924 hydro | 6 | 1991 | Not reached through 2025 | −0.293 |
| Exclude the three port measures | 13 | 1991 | Not reached through 2025 | −0.003 |
| Rail, steel, cement and hydro | 4 | 1979 | 2002 | +0.525 |
| Remove the Chinese PRE backfills | 16 | 1993 | 2012 | +0.168 |
| Steel/cement target lower bounds (5 / 3 Mt) | 16 | 1995 | 2012 | +0.155 |
| Steel/cement target upper bounds (10 / 8 Mt) | 16 | 1995 | 2012 | +0.155 |

Every scenario retains the common 1875–2025 support, log interpolation, pooled or own standardization and ±3 winsorization. Subsets remove measures from both countries and from their target bars. Target-only changes leave the country lines unchanged. The backfill scenario removes only PRE entries; other estimated early anchors remain, and uncovered years take the existing −3 floor. Scenario spans are assumption checks; no confidence interval has been estimated. Four national physical series narrow the question and retain source limitations, including hydro capacity scope.

Removing each of the sixteen measures in turn produces pooled first-at-or-above years of 2009–2016 and positive 2025 gaps of +0.088 to +0.264. Removing all port measures together eliminates that result through 2025. The baseline is robust to these individual deletions, but depends on the basket as a whole.

## Corrections since v008

- Port aggregates now end at the last year with coverage for every component (2024 for Bohai and the delta), then carry the aggregate to 2025. v008 treated an expired component as zero, producing artificial endpoint drops. No new raw observations were invented.
- This changes China’s own endpoint from 1.59 to 1.62 and pooled endpoint from 1.12 to 1.15; the baseline target and pooled crossing years remain unchanged.
- Exact observed values are preserved during log interpolation. This corrects the Mississippi sediment target crossing from 1981 to its observed 1980 equality.
- Chart targets labeled imputed now carry imputed provenance, with dotted lines retained. The sediment-halving rule is explicitly imputed; Sun’s two halves describe flood-prevention work, not a 50% reduction in sediment.
- Embedded-series captions now agree with calculations: national hydro 1983 and the Xinjiang population proxy 2018. The road model yields 2002 but is flagged against the official 2000 census and the unverified macadam specification.

Run `node scripts/extract_data.mjs`, both composite modes, then `node scripts/validate.mjs`. Validation checks 9,664 per-series year values across page and standalone implementations, constant membership, finite bounded z values, exact observed anchors, aggregate endpoints, provenance and fresh exports. CSV scenario and leave-one-out outputs are in data/.
