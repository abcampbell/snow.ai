---
name: composite-index-method
description: Use when averaging or z-scoring several time series into one composite index — cross-country or cross-measure scorecards, target-vs-actual bars, any 'relative basis' comparison or 'when did X pass the bar' question.
---

# Composite index method

A composite built from several time series is only as honest as its support, its standardization and its labeling. Every step below exists because skipping it produced a wrong chart once (the Sun Yat-sen ledger, Oct 2026). Do them in order.

## 1. Common support before anything else

Put every series on one annual calendar from a **common start year** to a **common end year** before averaging.

- **Floor, don't omit.** Where the thing did not yet exist (railways before 1876, containers before 1956), hold the series at a floor that scores the winsor minimum (z = −3). A series that simply *enters* the average mid-sample produces a step down in its first year — the "why did the US drop in 1964" bug (two container series entering).
- **End aggregates at common component coverage.** Sum component series only through the earliest component endpoint, then carry the aggregate. Treating an expired component as zero makes an artificial decline. Before-component reporting gaps remain a separate backfill problem.
- **Carry forward, don't drop.** Where the latest figure is a 2020 census and other series run to 2025, carry the last value forward to the common end. Series that *leave* produce a dip or spike in the last years — the "why is the US going down at the end" bug (six census series ending in 2020).
- **Exclude filled years from the statistics.** Floor and carried-forward years are support, not data: compute each series' mean and sd over interpolated annual log values inside its observation span. Raw anchors retain their exact values. Filled years outside that span are excluded.

Check: print the count of series in the average for every year. It must be constant. Any step in the composite that coincides with a series' first or last data year is an artifact.

## 2. Transform

- Interpolate log-linearly between observations; z-score the log10 values.
- Sign-flip lower-is-better series (sediment, mortality, cost).
- **Winsorize at ±3.** A nearly flat series (US forest cover, 33–36% for a century) has a tiny sd and gives any target a z of ±70 that swamps the mean.
- Units must match across entities before pooling (Gt vs Mt broke a pooled run once).
- A target far outside a short series' window (a river-freight series starting in 1980 at six times the 1921 target) scores an artificial −3: extend the series back with estimates, or flag it.

## 3. Choose, and name, the standardization

- **Own-distribution z**: each entity against its own history. Answers "how far along its own curve is this entity." Two entities' lines crossing here does **not** mean one passed the other.
- **Pooled z**: one mean/sd per measure from the union of all entities' real observations. Places the selected paired measures on a shared numerical scale. A crossing indicates a lead within that index. Its interpretation depends on comparable units, geographic coverage, counting rules and measure selection.

Always say which one a chart is. "Did X pass Y" is answered by the pooled version; offer both as a toggle. Relative targets and editorial relative imputations can give different bars per entity even under pooling; draw both. The Northwestern +10 M proposal is textual; halving sediment is imputed.

## 4. Interpret end levels correctly

The latest z of a series is the shape of its history, not its size: an unbroken exponential ends near +1.7 (√3), a hockey stick near +2.5 to +3, a series that peaked decades ago near 0 or below. A mature economy scores ~+0.9 and a late developer ~+1.6 on identical measures. Say so whenever end levels are compared.

## 5. Targets and bars

- Compute each target's z in the same distribution as its series (own or pooled, matching the chart).
- Label every target by provenance: **text** (a number in the source, with page), **inferred** (from a capital sum or a named comparator at period prices), **imputed** (no figure given). Show the composite bar with and without imputed targets.
- Relative targets are applied to the comparison entity's baseline and must disclose stock/flow and geographic adaptations. Keep the source's actual proposal distinct from editorial imputations such as sediment halving.
- Test alternative baskets, leave-one-out deletions, backfill assumptions and target bounds. Removing a target category removes its measures from the line and the bar together.
- Report crossing years per series and for the composite, with the window stated.

## 6. Pre-ship checks

1. Series count per year constant?
2. Per-series table: first and last real year, z now, target z, crossing year. Any |z| at the winsor limit — floor, window artifact, or real?
3. Any sd < 0.05 in log space? Winsorize or drop from the bar.
4. Units identical across entities?
5. Caption states window, standardization, winsor, which targets are imputed, and what a crossing means.

Reference implementation: `scripts/composite.mjs` in this project.

## v009 source limits

See `docs/validation.md`. The −3 convention before recorded coverage includes unknown early values as well as true nonexistence. Reporting starts are not evidence of a zero stock. Cross-country units, boundaries and definitions need source-level harmonization; numerical reproducibility alone cannot establish their equivalence. Standardization includes annual interpolated values, so estimates spanning many years have substantial influence.
