# Port history research — 4 November 2026

## Main editorial finding

The port story contains two different kinds of continuity. The Republican government actually took up Sun's Northern Port proposal, leaving an identifiable institutional and documentary trail. For the late twentieth-century ports, the sources checked here establish modern planning, construction, financing and retrospective association with Sun; they do not establish an uninterrupted transfer of his design. Use the latter as regional capacity achievements and geographical echoes, while investigating transmission further.

## 1. What Sun specified — primary text checked

Sun Yat-sen, *The International Development of China* (New York and London: G. P. Putnam's Sons, 1922), Program I, Part I, pp. 13–17, Map I, and Program II, Part I, pp. 30–35, Map III. Full public-domain HTML checked at [Project Gutenberg](https://www.gutenberg.org/files/45188/45188-h/45188-h.htm).

- **Northern site:** p. 14 places the proposed port between the mouths of the Tsingho and Lwanho, midway along the Taku–Chinwangtao coast. This is a specified proposed harbor, rather than an instruction to add the total cargo of modern Tangshan and Tianjin.
- **New city and finance:** pp. 15–16 propose national acquisition of two or three hundred square miles for a new city. The Philadelphia-within-forty-years comparison belongs to that new settlement and land-value financing argument. It does not identify the later administrative population of Tianjin as the intended test.
- **Design status:** p. 17 explicitly leaves detailed planning and estimates to experts after surveys and soundings. The map and diagrams are a rough reference, which matters when comparing them with subsequent engineering designs.
- **Eastern site:** pp. 31–32 explicitly locate the new harbor in the mainland bay between the Chapu and Kanpu promontories, bounded by an intended seawall. Map III follows. This is a stronger locator than the generic phrase “Hangzhou Bay.” Yangshan's offshore island site is different.

## 2. A documented Republican afterlife — scholarly full text checked

**Citation:** Kan Li, “River Conservancy and the Undetermined Future of the Port of Tianjin, 1888–1937,” *Open Rivers: Rethinking Water, Place & Community* 8 (Fall 2017): 64–86. DOI [10.24926/2471190X.3484](https://doi.org/10.24926/2471190X.3484). [Full HTML](https://openrivers.lib.umn.edu/article/river-conservancy-and-the-undetermined-future-of-the-port-of-tianjin/); [PDF](https://openrivers.lib.umn.edu/wp-content/uploads/2017/11/6_kan_feature_fall17.pdf).

**Concise historical synthesis suitable for the book:** Li identifies the North China Conservancy Commission's 1928 revival of Sun's port, including budgets, funding arrangements and survey teams. Work halted in 1932. Japanese planners later chose Tanggu over Sun's site; after the war, engineers again advocated the original alternative. The PRC subsequently continued Tanggu. This is evidence of direct Republican reception followed by competing project lineages, rather than a continuous construction program culminating automatically in today's ports.

**Exact locators:** section “The Great Northern Port,” printed pp. 78–80; institutional mission p. 79; preparations, stoppage, alternative Tanggu lineage and postwar advocacy p. 80. Endnotes 62–64 on printed pp. 85–86 identify the earlier documents. The PDF includes four preliminary pages, so printed p. 80 is PDF page 21 (zero-based index 20).

**Earlier documents identified through Li, not independently inspected:**

- Li Shutian, “Beifang dagang zhi chubu jihua” 北方大港之初步计划, *Huabei shuili yuekan* 华北水利月刊 2, no. 9 (1929): 122–23.
- “Beifang dagang gongzuo tingdun” 北方大港工作的停顿, *Shen Bao*, 28 May 1932.
- *Shen Bao*, 7 October 1947 and 2 February 1948; exact article titles and page numbers remain to be recovered.

Those are retrieval leads. Cite them as “cited in Li” until their scans have been checked. Avoid presenting them as primary texts personally consulted in this pass.

## 3. Modern Jingtang — primary government and company records checked

[Tangshan Port Group's 3 June 2010 preliminary IPO prospectus, reproduced in full by Sina Finance](https://money.finance.sina.com.cn/corp/view/vISSUE_RaiseExplanationDetail.php?id=569840&stockid=601000), printed pp. 1–1–27 to 1–1–28, records preparation beginning November 1984, construction in August 1989, domestic navigation in July 1992 and the port authority's establishment on 18 July 1992. This distinguishes the beginning of construction from opening to traffic.

[Beijing Government General Office notice 京政办发〔1994〕31号](https://www.beijing.gov.cn/zhengce/zfwj/zfwj/bgtwj/201905/t20190523_74436.html), 19 April 1994, records Beijing and Tangshan jointly investing in and operating Jingtang Port and creating a port authority. Its Beijing office was to raise construction finance, introduce projects and coordinate work. This supplies concrete evidence of the later financing arrangement, distinct from Sun's proposed international organization.

Neither inspected passage establishes that the 1980s project inherited the 1929 surveys or a continuous Sun-era design organization. That missing link remains a research question.

## 4. Caofeidian — a later contested project, not a self-executing prophecy

The Chinese Peasants and Workers Democratic Party's [2006 participant account](https://ngd.org.cn/xwzx/ywdt/296.htm), “农工民主党为曹妃甸矿石码头建设项目建言纪实,” dated 13 March 2006, documents advocacy from 1997, an August 1998 expert inspection, a project assessment interrupted around 2000 by debate about steel-industry needs, the 27 December 2004 regional port-planning decision and the 16 December 2005 opening ceremony. This is a near-contemporary organizational account by a participant claiming credit. It supports the modern project's contested planning process and opening date; its self-description is not independent evaluation of its own influence.

The [2014 People's Political Consultative Daily retrospective](https://dangshi.people.com.cn/n/2014/0213/c85037-24348222.html), republished by People's Daily's history site, associates modern Tangshan ports with Sun's Northern Port vision. It is evidence that the connection is publicly commemorated. It does not itself prove transfer of old surveys into modern design.

## 5. Yangshan — physical success at a different specified site

Shanghai's [7 December 2006 official briefing](https://www.shanghai.gov.cn/nw9822/20200906/0001-9822_185604.html) places Yangshan in Zhejiang's Shengsi island waters and confirms opening on 10 December 2005. Its [5 December 2008 construction briefing](https://www.shanghai.gov.cn/nw9822/20200906/0001-9822_310040.html), reporting deputy project commander Liu Zuoliang, attributes the modern initiative to container growth, insufficient deep-water capacity and the Shanghai shipping-center strategy. It describes an island/reclamation port with the Donghai Bridge, and six years of site assessment.

Read together with Sun pp. 31–32, these sources support a regional echo of his search for a better deep-water outlet, while contradicting an assertion that Yangshan literally occupies the new harbor site he specified. Avoid “Yangshan is where Sun said” and replace with a precise distinction between the Chapu–Kanpu proposal and the later island solution.

## Suggested scorecard treatment

- Keep **modern regional port capacity achieved** separate from **exact site/design fulfilled**.
- The Great Northern Port has documentary Republican reception, followed by interruption and divergent projects. Present Jingtang/Caofeidian as later regional developments and explain the evidence gap concerning design transmission.
- The Great Eastern Port should carry an explicit **location/design differs** qualification; Yangshan's completion cannot by itself demonstrate literal realization of the Chapu–Kanpu project.
- Tianjin municipality population and a sum of neighboring cargo totals remain proxies. A reader should be able to distinguish their usefulness for scale from proof about the new city and harbor.
- Any change to “built/partial” counts should state the revised criterion, so a stricter historical classification is not mistaken for disappearance of the modern engineering achievement.

## Link audit correction ? 4 November 2026

The original Shanghai Stock Exchange PDF URL returned HTTP 404 on a direct GET, despite remaining readable through the search tool?s PDF extraction. The active citation now uses Sina Finance?s full reproduction of the same 3 June 2010 preliminary filing: HTTP 200, title/date and historical passage checked directly, with the printed page markers retained. The Eastmoney-hosted final prospectus is an additional working PDF mirror (HTTP 200, 3,571,065 bytes): https://pdf.dfcfw.com/pdf/H2_AN201203010004632976_1.pdf. It carries the same port-history passage at printed p. 1?1?28 but is a different filing edition, so it is recorded as an alternate rather than silently substituted for the preliminary prospectus.
