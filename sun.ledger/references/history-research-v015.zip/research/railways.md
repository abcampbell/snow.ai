# Railway history research — 4 November 2026

## What can now be said

Sun’s national railway vision predates the 1921 preface. An official Sunology transcription dates his Shanghai interview on three trunk corridors to 25 June 1912, with its newspaper source dated the following day. The collected-works locator is vol. 2, pp. 459–461, especially p. 460. It is evidence of a political and economic planning vision, rather than a completed engineering survey. [Sun, 1912](https://sunology.yatsen.gov.tw/detail/bd4665d44b11bd6b9864c2abf947f9f0/)

The bibliography’s missing railway author is Richard Louis Edmonds. His article appeared in September 1987, not 2009: the latter is Cambridge’s digitization date. The public opening extract attributes the often-repeated 80% overlap between early PRC construction and Nationalist projections to Lippit. Its first reference traces the connection through Chang’s 1943 account. This is a chain of scholarly argument, not a causal fraction verified by this project. References 19 and 23 flag territorial changes and ambiguity in treating nearby parallel routes as the same line. Only the published extract and references were read. [Edmonds, 1987, extract and refs. 1, 19, 23](https://doi.org/10.1017/S0305741000050980)

Lippit’s own public opening extract identifies Chang Kia-ngau’s wartime ten-year railway proposal and the hope that converted Western war industries would supply construction, echoing an earlier financing idea. The full article and its mileage calculation were not accessed. [Lippit, 1966, p. 101 extract](https://doi.org/10.1017/S0305741000021718)

## A stronger concrete case: Chengdu–Chongqing

The official Chongqing local-history account places this line in the late-Qing Sichuan–Hankou scheme, preceding Sun’s book. It records a Chengdu–Chongqing preparatory office in 1932 and Republican work on surveys, earthworks, roadbed, small bridges and culverts before 1949, while noting that rails had not yet been laid. The page’s original metadata date is 15 June 2021; its 2023 URL reflects migration. [Deng Chaojun, section III](https://dfz.cq.gov.cn/fzyd/llyj/202311/t20231102_12509915.html)

The railway administration’s historical account dates PRC construction from June 1950 and opening to July 1952. Its opening paragraphs also acknowledge the late-Qing antecedent. [National Railway Administration, 8 May 2017](https://source.nra.gov.cn/tlfc/tpsy/202204/t20220405_293013.shtml)

This is a useful distinction for the book: PRC construction belongs in a longer history of inherited projects and accumulated preparatory work. Shared geography alone cannot identify which portion of that inheritance came specifically from Sun. These retrospectives do not establish exactly which earlier surveys or structures the 1950 builders reused; surviving engineering-office files would be needed for that stronger claim.

## Reading and archive work still needed

- Read Chang’s original 1943 book, particularly pp. 46–47 and 50, instead of relying on Edmonds’s references. Contemporary review metadata verifies the publication but not those page contents.
- Obtain the full Edmonds and Lippit articles to inspect map categories, route matching and the denominator behind the 80% statement.
- Consult Köll’s *Railroads and the Transformation of China* (Harvard, 2019) for the organizational bridge across 1949; only summary/metadata was consulted here. Do not manufacture a personnel chain from the general institutional argument.
- Recover the Chengdu–Chongqing preparatory-office and 1949–50 takeover dossiers to establish which surveys, staff, equipment and works passed into the PRC project. No named engineer-to-engineer transfer chain has yet been verified in this pass.

Source access levels and exact bibliographic details are recorded in `railways_sources.json`. No historical primary text has been quoted at length. The railway case does not change the v009 numerical series.
