# Three Gorges: evidence for a lineage, and where it breaks

Research checked 4 November 2026. These notes distinguish direct historical text, later institutional recollection, and scholarship inspected only at abstract level. Source IDs match `three_gorges_sources.json`.

## Main conclusion

A history of successive proposals, international technical work and continuing Chinese engineering participation is supportable. The evidence does **not** establish that the operating Three Gorges project is simply Sun's engineering design carried out unchanged. The strongest chain runs from an early navigation/power proposal, through National Resources Commission (NRC) cooperation with American engineers, into personnel and research institutions that remained active under the PRC. Financing and design decisions changed repeatedly.

## Sun's proposal: two texts, different claims

- The [1922 Putnam text](https://www.gutenberg.org/files/45188/45188-h/45188-h.htm), Program II, Part IV, p. 74, proposes dams at rapids to provide locks and power along the upper Yangtze. It does not specify the present Sandouping dam or an installed-capacity target there.
- The [official Sunology transcription](https://sunology.yatsen.gov.tw/detail/824ec0537d38ca6d6b03c437ba07f542/?seq=1) dates **People's Livelihood, Lecture Three to 17 August 1924**. In the fertilizer/electrification discussion, Sun reports investigators' estimate of **more than thirty million horsepower** for the **Yichang-Wanxian stretch**. The Chinese wording explicitly includes an amount above the round thirty-million figure. [sun1924-livelihood3]
- Thirty million mechanical horsepower is approximately 22.37 GW, so the ledger's rounded 22.4 GW is an analytical benchmark. The source concerns regional potential, exceeds the round figure, and is not an exact specification for one dam. The present 22.5 GW numerical resemblance should not be called an exact target fulfilled.

## The wartime technical and financial record

**15 December 1944:** Wong Wen-hao's letter reports Savage's stay as 25 May-24 November 1944, describes visits and changes to Chinese hydro designs, and seeks support for detailed Yangtze design. This contemporaneous statement is preferable to retrospective accounts that place his arrival generically in June. [frus1944-wong; [document](https://history.state.gov/historicaldocuments/frus1944v06/d871), around printed p. 1155]

**26 January 1945:** Hurley transmits T. V. Soong's request to designate the Bureau of Reclamation for design and eventual construction, with Chinese costs and technical-contract arrangements under discussion. This is evidence of negotiation, not completed financing. [frus1945-hurley; [telegram 115](https://history.state.gov/historicaldocuments/frus1945v07/d1080)]

**11 July 1945:** Grew's telegram objects to spending at least $500,000 on further reporting given industrial and financial constraints; it says US construction assistance is not expected for many years. Financing was already an obstacle before the project's later suspension. [frus1945-grew; [telegram 1075](https://history.state.gov/historicaldocuments/frus1945v07/d1088), numbered points 1-5]

**May 1946-May 1947:** The PRC embassy's retrospective chronology records a joint-design agreement and subsequent suspension amid inflation and economic crisis. Use those dated entries with attribution rather than presenting them as an inspected original agreement. [prc2003-gorges-chronology; [chronology](https://nz.china-embassy.gov.cn/eng/ztbd/sxgc/200310/t20031027_946122.html)]

## A personnel bridge worth naming

Tsinghua's [2002 biography](https://www.tsinghua.edu.cn/info/2022/78362.htm) records Zhang Guangdou's NRC assignment to American hydro institutions in 1943 and return for Three Gorges planning in April 1945. It also says he helped preserve technical files during the 1948-49 transition, then taught at Tsinghua and advised water projects. This supports an attributed institutional/personnel bridge; it does not identify which particular pre-1949 design sheets the final dam adopted. [tsinghua2002-zhang]

Ying Jia Tan's open-access monograph reconstructs the Chinese-engineer/USBR relationship from archives and correspondence. Chapter 5 treats Zhang's contact with Savage, preliminary survey deficiencies, postwar design work and Zhang's later advocacy. Its notes identify original collections to consult next. [tan2021-electricity, *Turning the Tide*, pp. 112-137, especially 123-137; notes 223-227; [book](https://ecommons.cornell.edu/entities/publication/c518f6b8-d11c-4e89-b876-b09b038295e4)]

## Later decisions were decisions, not automatic inheritance

The official chronology records renewed PRC work in the 1950s, Gezhouba in 1970, repeated later feasibility reviews, NPC approval on **3 April 1992**, and construction launch on **14 December 1994**. That sequence contains redesign and political choice, not uninterrupted implementation. [prc2003-gorges-chronology]

The National Energy Administration's [2012 commissioning chronology](https://www.nea.gov.cn/2012-07/05/c_131696251.htm) separates the **first unit on 10 July 2003** from the **last major unit on 4 July 2012**, when reported total installed capacity reached **22.5 GW**. "Built in 2003" and "built in 2012" refer to different milestones. [nea2012-gorges]

The State Council's [18 May 2011 meeting report](https://my.china-embassy.gov.cn/chn/zgxw/201106/t20110602_1719203.htm) acknowledged unresolved resettlement, ecological and geological-hazard problems and downstream effects, while also reporting benefits. A construction ledger should cite this official acknowledgement and keep physical commissioning separate from a net social-benefit verdict. [statecouncil2011-gorges]

## Bibliographic correction and access limits

The inherited Meyskens attribution was substantially right but incomplete. The verified reference is:

**Covell F. Meyskens. "The Three Gorges Dam and Sino-American Hydraulic Planning." In *Uneasy Allies: Sino-American Relations at the Grassroots, 1937-1949*, edited by Zach Fredman and Judd Kinzley, 95-112. Cambridge University Press, 2024. Chapter 6. DOI [10.1017/9781009534970.009](https://doi.org/10.1017/9781009534970.009).** Online publication 12 December; print 19 December 2024.

Only publisher summary and metadata were inspected. They establish the chapter's scope from Sun to the 1940s; specific unseen arguments should not be attributed to it. Christopher Sneddon's *Concrete Revolution*, chapter 2, pp. 28-51 (2015), is another verified scholarly lead; only its abstract was inspected. [meyskens2024-gorges; sneddon2015-fraternity]

## Contradictions to preserve rather than silently reconcile

1. A Tsinghua retrospective account of Zhang suggests that the United States offered a billion-dollar construction loan. The July 1945 FRUS telegram explicitly denies a near-term financing prospect. The safest account describes requests, changing expectations and financing resistance; do not print a granted-loan claim without original documentation.
2. NARA's [photograph/collection description](https://www.archives.gov/denver/highlights/yangtze-river-project) dates withdrawal of American support to 1949, whereas the design-suspension chronologies give 1947. They can concern different institutional events. Retain the distinction instead of reducing them to one unexplained date. [nara1944-savage]
3. First generation, dam-body completion, full power-station commissioning, navigation facilities and whole-project acceptance have different completion dates. Name the milestone each time.

## Archival follow-up, explicitly not inspected

- NARA, RG 115, **Case Files on the Yangtze Gorge and Three Gorges Dam, China, 1943-1996**. The NARA collection page says many records are undigitized. The 1944 photograph is National Archives Identifier **431966320**.
- Tan's notes cite Savage, **"Excerpts from Preliminary Report on Yangtze Gorges Project, Chungking, China," 9 November 1944**, RG 115, Yangtze Gorge Project (1943-1949), box 10, NARA Denver. That archival report was identified through the monograph's references, not read directly here.
- Tan also cites NRC Papers at Academia Historica, Taipei, and John Lucian Savage / John S. Cotton collections at the American Heritage Center, University of Wyoming. These are research leads; request the original plans, budgets and correspondence before claiming exact design transmission.

## Suggested integration into the book

The short narrative can move through five documented turns: Sun's broad navigation/power program; NRC engineers and American technical collaboration; the conflict over financial feasibility visible in 1945 diplomacy; Zhang's cross-regime professional career; and renewed PRC reviews leading to 1992 approval and later construction. This supplies historical mechanisms while preserving uncertainty about whether any particular design was inherited unchanged. The 1924 horsepower paragraph should be described as a regional potential estimate, and the modern 22.4 GW target tagged as the ledger's rounded comparator.
